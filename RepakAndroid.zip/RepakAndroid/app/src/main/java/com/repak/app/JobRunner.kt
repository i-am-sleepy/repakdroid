package com.repak.app

import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

object JobRunner {
    data class State(
        val running: Boolean = false,
        val done: Int = 0,
        val total: Int = 0,
        val current: String = "",
        val log: String = "Ready.\n",
    )

    val state = MutableStateFlow(State())
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    fun start(ctx: Context, title: String, block: (ProgressListener) -> String) {
        if (state.value.running) return
        val app = ctx.applicationContext
        state.value = State(running = true, log = "$title…\n")
        ContextCompat.startForegroundService(app, Intent(app, WorkService::class.java))
        scope.launch {
            val listener = object : ProgressListener {
                override fun onProgress(done: Int, total: Int, name: String) {
                    state.update { it.copy(done = done, total = total, current = name) }
                }
            }
            val result = try {
                block(listener)
            } catch (t: Throwable) {
                "ERROR: ${t.message ?: t.javaClass.simpleName}"
            }
            state.update { it.copy(running = false, log = it.log + result + "\n") }
            app.stopService(Intent(app, WorkService::class.java))
        }
    }
}
