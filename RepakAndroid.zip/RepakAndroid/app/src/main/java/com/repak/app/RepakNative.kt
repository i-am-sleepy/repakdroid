package com.repak.app

interface ProgressListener {
    fun onProgress(done: Int, total: Int, name: String)
}

/** JNI bridge to librepak_jni.so (Rust, built from /rust). Every call returns text; errors start with "ERROR:". */
object RepakNative {
    init { System.loadLibrary("repak_jni") }

    external fun list(pakPath: String, aesKey: String): String
    external fun unpack(pakPath: String, outDir: String, aesKey: String, cb: ProgressListener): String
    external fun pack(inDir: String, outPak: String, version: String, mountPoint: String, cb: ProgressListener): String
}
