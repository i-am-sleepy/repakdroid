package com.repak.app

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.io.File

object Ticker { val tick = mutableIntStateOf(0) }

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val perms = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= 33) perms += Manifest.permission.POST_NOTIFICATIONS
        if (Build.VERSION.SDK_INT < 30) {
            perms += Manifest.permission.READ_EXTERNAL_STORAGE
            perms += Manifest.permission.WRITE_EXTERNAL_STORAGE
        }
        if (perms.isNotEmpty()) requestPermissions(perms.toTypedArray(), 1)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                Surface(Modifier.fillMaxSize()) { App() }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        Ticker.tick.intValue++
    }
}

@Composable
fun App() {
    val ctx = LocalContext.current
    val st by JobRunner.state.collectAsState()
    val tick = Ticker.tick.intValue

    var hasAccess by remember { mutableStateOf(Files.hasAllFiles()) }
    var dirs by remember { mutableStateOf(Files.workDirs()) }
    var pakUri by remember { mutableStateOf<Uri?>(null) }
    var pakName by remember { mutableStateOf("") }
    var key by remember { mutableStateOf("") }
    var selDir by remember { mutableStateOf<String?>(null) }
    var outName by remember { mutableStateOf("pakchunk0-Android_P.pak") }

    LaunchedEffect(tick, st.running) {
        hasAccess = Files.hasAllFiles()
        dirs = Files.workDirs()
    }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            pakUri = uri
            pakName = Files.displayName(ctx, uri)
        }
    }

    Column(
        Modifier.fillMaxSize().statusBarsPadding().padding(16.dp).verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Text("Repak", style = MaterialTheme.typography.headlineMedium)
        Text("Work folder: /storage/emulated/0/RepakWork", fontSize = 12.sp)

        if (!hasAccess) {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("This app needs \"All files access\" to read and write the work folder.")
                    Button(onClick = {
                        val i = if (Build.VERSION.SDK_INT >= 30)
                            Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:${ctx.packageName}"))
                        else Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${ctx.packageName}"))
                        ctx.startActivity(i)
                    }) { Text("Grant access") }
                }
            }
        }

        HorizontalDivider()
        Text("1. Unpack / list", style = MaterialTheme.typography.titleMedium)
        OutlinedButton(onClick = { picker.launch(arrayOf("*/*")) }, enabled = !st.running) {
            Text(if (pakName.isEmpty()) "Select .pak file" else "Selected: $pakName")
        }
        OutlinedTextField(
            value = key, onValueChange = { key = it },
            label = { Text("AES key (optional, hex 0x… or base64)") },
            singleLine = true, modifier = Modifier.fillMaxWidth(),
        )
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(enabled = hasAccess && !st.running && pakUri != null, onClick = {
                val uri = pakUri!!
                val k = key
                JobRunner.start(ctx, "Listing $pakName") { cb ->
                    val p = Files.resolve(ctx, uri, cb)
                    val r = RepakNative.list(p, k)
                    if (r.startsWith("ERROR")) r else {
                        val f = File(Files.work(), pakName.removeSuffix(".pak") + "_filelist.txt")
                        f.writeText(r)
                        val lines = r.lines()
                        lines.take(300).joinToString("\n") +
                            (if (lines.size > 300) "\n… (${lines.size - 300} more lines)" else "") +
                            "\n\nFull list saved to ${f.path}"
                    }
                }
            }) { Text("List") }
            Button(enabled = hasAccess && !st.running && pakUri != null, onClick = {
                val uri = pakUri!!
                val k = key
                val name = pakName
                JobRunner.start(ctx, "Unpacking $name") { cb ->
                    val p = Files.resolve(ctx, uri, cb)
                    val out = File(Files.work(), name.removeSuffix(".pak") + "_unpacked")
                    RepakNative.unpack(p, out.path, k, cb)
                }
            }) { Text("Unpack") }
        }

        HorizontalDivider()
        Text("2. Repack a folder into a pak", style = MaterialTheme.typography.titleMedium)
        Text(
            "Tip: for a patch pak, delete every file you did NOT change from the unpacked folder first, " +
                "otherwise the patch will be as big as the original.",
            fontSize = 12.sp,
        )
        if (dirs.isEmpty()) Text("No folders in the work folder yet. Unpack something first.", fontSize = 12.sp)
        dirs.forEach { d ->
            Row(
                Modifier.fillMaxWidth().clickable { selDir = d.path },
                verticalAlignment = Alignment.CenterVertically,
            ) {
                RadioButton(selected = selDir == d.path, onClick = { selDir = d.path })
                Text(d.name)
            }
        }
        OutlinedTextField(
            value = outName, onValueChange = { outName = it },
            label = { Text("Output pak name") }, singleLine = true, modifier = Modifier.fillMaxWidth(),
        )
        Button(enabled = hasAccess && !st.running && selDir != null && outName.isNotBlank(), onClick = {
            val dir = File(selDir!!)
            val name = outName.trim()
            JobRunner.start(ctx, "Packing ${dir.name}") { cb ->
                val info = Files.readInfo(dir)
                val out = File(Files.work(), "out/$name")
                out.parentFile?.mkdirs()
                RepakNative.pack(dir.path, out.path, info["version"] ?: "V8B", info["mount"] ?: "../../../", cb)
            }
        }) { Text("Pack") }

        HorizontalDivider()
        if (st.running) {
            Text(st.current, fontSize = 12.sp)
            if (st.total > 0) LinearProgressIndicator(
                progress = { (st.done.toFloat() / st.total).coerceIn(0f, 1f) },
                modifier = Modifier.fillMaxWidth(),
            ) else LinearProgressIndicator(Modifier.fillMaxWidth())
            if (st.total > 0) Text("${st.done} / ${st.total}", fontSize = 12.sp)
        }
        Box(Modifier.fillMaxWidth().height(320.dp).verticalScroll(rememberScrollState())) {
            Text(st.log, fontFamily = FontFamily.Monospace, fontSize = 12.sp)
        }
    }
}
