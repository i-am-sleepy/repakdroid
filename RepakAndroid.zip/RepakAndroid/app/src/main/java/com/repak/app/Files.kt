package com.repak.app

import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.DocumentsContract
import android.provider.OpenableColumns
import java.io.File

object Files {
    fun work(): File = File(Environment.getExternalStorageDirectory(), "RepakWork").also { it.mkdirs() }

    fun hasAllFiles(): Boolean =
        if (Build.VERSION.SDK_INT >= 30) Environment.isExternalStorageManager() else true

    fun workDirs(): List<File> =
        if (!hasAllFiles()) emptyList()
        else work().listFiles()?.filter { it.isDirectory && it.name != "input" && it.name != "out" }
            ?.sortedBy { it.name } ?: emptyList()

    fun readInfo(dir: File): Map<String, String> {
        val f = File(dir, "_pakinfo.txt")
        if (!f.exists()) return emptyMap()
        return f.readLines().mapNotNull {
            val i = it.indexOf('=')
            if (i > 0) it.substring(0, i) to it.substring(i + 1) else null
        }.toMap()
    }

    fun displayName(ctx: Context, uri: Uri): String {
        ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
            if (it.moveToFirst()) return it.getString(0)
        }
        return uri.lastPathSegment?.substringAfterLast('/') ?: "input.pak"
    }

    private fun size(ctx: Context, uri: Uri): Long {
        ctx.contentResolver.query(uri, arrayOf(OpenableColumns.SIZE), null, null, null)?.use {
            if (it.moveToFirst() && !it.isNull(0)) return it.getLong(0)
        }
        return -1
    }

    /** Internal-storage document URIs can be mapped to a real path (we hold All-files access). */
    private fun uriToPath(uri: Uri): String? {
        if (uri.authority != "com.android.externalstorage.documents") return null
        val id = runCatching { DocumentsContract.getDocumentId(uri) }.getOrNull() ?: return null
        val parts = id.split(":", limit = 2)
        if (parts.size != 2 || parts[0] != "primary") return null
        return File(Environment.getExternalStorageDirectory(), parts[1]).path
    }

    /** Returns a real file path for the picked pak, copying it into RepakWork/input if needed. */
    fun resolve(ctx: Context, uri: Uri, cb: ProgressListener): String {
        uriToPath(uri)?.let { if (File(it).canRead()) return it }
        val dest = File(work(), "input/${displayName(ctx, uri)}")
        dest.parentFile?.mkdirs()
        val totalMb = (size(ctx, uri) / (1024 * 1024)).toInt()
        val input = ctx.contentResolver.openInputStream(uri) ?: error("Cannot open file")
        input.use { i ->
            dest.outputStream().use { o ->
                val buf = ByteArray(1 shl 20)
                var copied = 0L
                while (true) {
                    val n = i.read(buf)
                    if (n < 0) break
                    o.write(buf, 0, n)
                    copied += n
                    cb.onProgress((copied / (1024 * 1024)).toInt(), totalMb, "Copying to work folder (MB)")
                }
            }
        }
        return dest.path
    }
}
