# Repak for Android

Kotlin/Compose app + Rust JNI library (built on the `repak` crate) to list, unpack and repack Unreal Engine .pak files on-device.

## Build on GitHub
1. Create a repo, put these files in it (see "Uploading" below).
2. Open the **Actions** tab -> **Build APK** (runs on every push; or "Run workflow").
3. When it's green, open the run and download the **repak-apk** artifact (a zip containing `app-debug.apk`).
4. Install the APK (allow "install unknown apps"), open it, tap **Grant access**.

## Uploading
GitHub's web uploader does not extract zips. Either:
- **Unzip first**, then drag the *contents* (including the hidden `.github` folder) into the repo, or
- **Upload the zip itself** to the repo root, then use *Add file -> Create new file*, name it
  `.github/workflows/build.yml`, and paste in the contents of `build.yml`. The workflow unzips the project for you.

## Using the app
- Work folder: `/storage/emulated/0/RepakWork`
- **Select .pak** -> **List** / **Unpack** (to `RepakWork/<name>_unpacked`). Encrypted pak? Enter the AES key.
- Edit files in the unpacked folder. For a patch pak, delete all files you did not change.
- **Pack** writes `RepakWork/out/<name>`. Copy it to the game's `Paks` folder (e.g. as `pakchunk0-Android_P.pak`).
- `_pakinfo.txt` in the unpacked folder stores the pak version and mount point; it is used when repacking.
  Edit it if you need a different version (V3 V5 V7 V8A V8B V9 V11).

## Notes
- Packed output is uncompressed and unencrypted, which UE4 accepts for patch paks.
- Only arm64 is built. For 32-bit phones add `-t armeabi-v7a`, the rust target `armv7-linux-androideabi`, and the ABI in `app/build.gradle.kts`.
- If the Rust step fails to compile, the repak crate API may have changed; the code is in `rust/src/lib.rs` (three small functions use it).
