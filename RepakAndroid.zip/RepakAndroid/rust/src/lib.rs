//! JNI wrapper around the `repak` crate for the Android app.
//! Kotlin side: com.repak.app.RepakNative

use jni::objects::{JObject, JString, JValue};
use jni::sys::jstring;
use jni::JNIEnv;
use repak::{PakBuilder, Version};
use std::fs::{self, File};
use std::io::{BufReader, BufWriter, Write};
use std::path::{Component, Path, PathBuf};

type Res<T> = Result<T, String>;
type Progress<'a> = &'a mut dyn FnMut(usize, usize, &str);

fn e<E: std::fmt::Display>(err: E) -> String {
    err.to_string()
}

// ---------- helpers ----------

fn parse_key(s: &str) -> Res<Option<aes::Aes256>> {
    let s = s.trim();
    if s.is_empty() {
        return Ok(None);
    }
    let hexs = s
        .strip_prefix("0x")
        .or_else(|| s.strip_prefix("0X"))
        .unwrap_or(s);
    let bytes: Vec<u8> = if hexs.len() == 64 && hexs.chars().all(|c| c.is_ascii_hexdigit()) {
        (0..64)
            .step_by(2)
            .map(|i| u8::from_str_radix(&hexs[i..i + 2], 16).unwrap())
            .collect()
    } else {
        use base64::Engine;
        base64::engine::general_purpose::STANDARD
            .decode(s)
            .map_err(|_| "AES key must be 64 hex chars (optionally prefixed 0x) or base64".to_string())?
    };
    if bytes.len() != 32 {
        return Err(format!("AES key must be 32 bytes, got {}", bytes.len()));
    }
    use aes::cipher::KeyInit;
    Ok(Some(aes::Aes256::new_from_slice(&bytes).map_err(e)?))
}

fn builder(key: &str) -> Res<PakBuilder> {
    let mut b = PakBuilder::new();
    if let Some(k) = parse_key(key)? {
        b = b.key(k);
    }
    Ok(b)
}

fn safe_rel(name: &str) -> Res<PathBuf> {
    let mut p = PathBuf::new();
    for c in Path::new(name).components() {
        match c {
            Component::Normal(x) => p.push(x),
            Component::CurDir => {}
            _ => return Err(format!("unsafe path in pak: {name}")),
        }
    }
    if p.as_os_str().is_empty() {
        return Err(format!("empty path in pak: {name}"));
    }
    Ok(p)
}

fn parse_version(s: &str) -> Res<Version> {
    Ok(match s.trim().to_uppercase().as_str() {
        "V3" => Version::V3,
        "V5" => Version::V5,
        "V7" => Version::V7,
        "V8A" => Version::V8A,
        "V8B" => Version::V8B,
        "V9" => Version::V9,
        "V11" => Version::V11,
        other => {
            return Err(format!(
                "unsupported pak version '{other}'. Edit _pakinfo.txt in the folder to one of: V3 V5 V7 V8A V8B V9 V11"
            ))
        }
    })
}

fn walk(dir: &Path, base: &Path, out: &mut Vec<(String, PathBuf)>) -> Res<()> {
    let mut entries: Vec<_> = fs::read_dir(dir).map_err(e)?.filter_map(|x| x.ok()).collect();
    entries.sort_by_key(|x| x.file_name());
    for en in entries {
        let p = en.path();
        if p.is_dir() {
            walk(&p, base, out)?;
        } else {
            let rel = p.strip_prefix(base).map_err(e)?;
            let rel_s = rel
                .components()
                .map(|c| c.as_os_str().to_string_lossy().into_owned())
                .collect::<Vec<_>>()
                .join("/");
            if rel_s == "_pakinfo.txt" {
                continue;
            }
            out.push((rel_s, p));
        }
    }
    Ok(())
}

// ---------- operations ----------

fn do_list(pak_path: &str, key: &str) -> Res<String> {
    let mut r = BufReader::new(File::open(pak_path).map_err(e)?);
    let pak = builder(key)?.reader(&mut r).map_err(e)?;
    let files = pak.files();
    let mut s = format!(
        "Version: {:?}\nMount point: {}\nFiles: {}\n\n",
        pak.version(),
        pak.mount_point(),
        files.len()
    );
    for f in files {
        s.push_str(&f);
        s.push('\n');
    }
    Ok(s)
}

fn do_unpack(pak_path: &str, out_dir: &str, key: &str, prog: Progress) -> Res<String> {
    let mut r = BufReader::new(File::open(pak_path).map_err(e)?);
    let pak = builder(key)?.reader(&mut r).map_err(e)?;
    let files = pak.files();
    let total = files.len();
    let out = PathBuf::from(out_dir);
    fs::create_dir_all(&out).map_err(e)?;

    fs::write(
        out.join("_pakinfo.txt"),
        format!("version={:?}\nmount={}\n", pak.version(), pak.mount_point()),
    )
    .map_err(e)?;

    let mut failed: Vec<String> = Vec::new();
    for (i, name) in files.iter().enumerate() {
        if i % 25 == 0 || i + 1 == total {
            prog(i + 1, total, name);
        }
        let res = (|| -> Res<()> {
            let dest = out.join(safe_rel(name)?);
            if let Some(parent) = dest.parent() {
                fs::create_dir_all(parent).map_err(e)?;
            }
            let mut w = BufWriter::new(File::create(&dest).map_err(e)?);
            pak.read_file(name, &mut r, &mut w).map_err(e)?;
            w.flush().map_err(e)?;
            Ok(())
        })();
        if let Err(err) = res {
            failed.push(format!("{name}: {err}"));
        }
    }

    let mut msg = format!("Unpacked {} of {} files to {}", total - failed.len(), total, out_dir);
    if !failed.is_empty() {
        msg.push_str(&format!("\n{} failed (first 10):\n", failed.len()));
        for f in failed.iter().take(10) {
            msg.push_str(f);
            msg.push('\n');
        }
        msg.push_str("If everything failed, the pak is probably encrypted: enter the AES key.");
    }
    Ok(msg)
}

fn do_pack(in_dir: &str, out_pak: &str, version: &str, mount: &str, prog: Progress) -> Res<String> {
    let base = PathBuf::from(in_dir);
    let mut files = Vec::new();
    walk(&base, &base, &mut files)?;
    if files.is_empty() {
        return Err("folder contains no files to pack".into());
    }
    let ver = parse_version(version)?;
    let writer = BufWriter::new(File::create(out_pak).map_err(e)?);
    let mut pak = PakBuilder::new().writer(writer, ver, mount.to_string(), None);
    let total = files.len();
    for (i, (rel, path)) in files.iter().enumerate() {
        if i % 25 == 0 || i + 1 == total {
            prog(i + 1, total, rel);
        }
        let data = fs::read(path).map_err(|x| format!("{rel}: {x}"))?;
        pak.write_file(rel, false, data).map_err(|x| format!("{rel}: {x}"))?;
    }
    let mut w = pak.write_index().map_err(e)?;
    w.flush().map_err(e)?;
    Ok(format!(
        "Packed {total} files into {out_pak}\n(version {version}, mount point '{mount}', uncompressed, unencrypted)"
    ))
}

// ---------- JNI glue ----------

fn jstr(env: &mut JNIEnv, s: &JString) -> Res<String> {
    env.get_string(s).map(String::from).map_err(e)
}

fn ret(env: &mut JNIEnv, r: Res<String>) -> jstring {
    let s = match r {
        Ok(s) => s,
        Err(err) => format!("ERROR: {err}"),
    };
    env.new_string(s)
        .map(|j| j.into_raw())
        .unwrap_or(std::ptr::null_mut())
}

#[no_mangle]
pub extern "system" fn Java_com_repak_app_RepakNative_list(
    mut env: JNIEnv,
    _this: JObject,
    pak: JString,
    key: JString,
) -> jstring {
    let r = (|| {
        let pak = jstr(&mut env, &pak)?;
        let key = jstr(&mut env, &key)?;
        do_list(&pak, &key)
    })();
    ret(&mut env, r)
}

#[no_mangle]
pub extern "system" fn Java_com_repak_app_RepakNative_unpack(
    mut env: JNIEnv,
    _this: JObject,
    pak: JString,
    out_dir: JString,
    key: JString,
    cb: JObject,
) -> jstring {
    let args = (|| -> Res<(String, String, String)> {
        Ok((jstr(&mut env, &pak)?, jstr(&mut env, &out_dir)?, jstr(&mut env, &key)?))
    })();
    let r = match args {
        Err(x) => Err(x),
        Ok((pak, out, key)) => {
            let mut prog = |d: usize, t: usize, n: &str| {
                if let Ok(js) = env.new_string(n) {
                    let _ = env.call_method(
                        &cb,
                        "onProgress",
                        "(IILjava/lang/String;)V",
                        &[JValue::Int(d as i32), JValue::Int(t as i32), JValue::Object(&js)],
                    );
                    let _ = env.exception_clear();
                }
            };
            do_unpack(&pak, &out, &key, &mut prog)
        }
    };
    ret(&mut env, r)
}

#[no_mangle]
pub extern "system" fn Java_com_repak_app_RepakNative_pack(
    mut env: JNIEnv,
    _this: JObject,
    in_dir: JString,
    out_pak: JString,
    version: JString,
    mount: JString,
    cb: JObject,
) -> jstring {
    let args = (|| -> Res<(String, String, String, String)> {
        Ok((
            jstr(&mut env, &in_dir)?,
            jstr(&mut env, &out_pak)?,
            jstr(&mut env, &version)?,
            jstr(&mut env, &mount)?,
        ))
    })();
    let r = match args {
        Err(x) => Err(x),
        Ok((dir, out, ver, mnt)) => {
            let mut prog = |d: usize, t: usize, n: &str| {
                if let Ok(js) = env.new_string(n) {
                    let _ = env.call_method(
                        &cb,
                        "onProgress",
                        "(IILjava/lang/String;)V",
                        &[JValue::Int(d as i32), JValue::Int(t as i32), JValue::Object(&js)],
                    );
                    let _ = env.exception_clear();
                }
            };
            do_pack(&dir, &out, &ver, &mnt, &mut prog)
        }
    };
    ret(&mut env, r)
}
